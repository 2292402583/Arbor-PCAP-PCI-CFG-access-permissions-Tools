# -*- coding: utf-8 -*-

import re
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from datetime import datetime

# 定义寄存器位宽选项（8, 16, 32）
SUPPORTED_WIDTHS = [8, 16, 32]

# 定义位的类型映射
FIELD_TYPE_MAPPINGS = {
    'RO': {'MASK': '0', 'RW1C': '0'},
    'RSVD': {'MASK': '0', 'RW1C': '0'},
    'RW': {'MASK': '1', 'RW1C': '0'},
    'RW1C': {'MASK': '1', 'RW1C': '1'},
    'UNDEFINED': {'MASK': '0', 'RW1C': '0'},
    'RSVDZ': {'MASK': '1', 'RW1C': '1'},
    'RW1CS': {'MASK': '1', 'RW1C': '1'},
    'RSVDP': {'MASK': '1', 'RW1C': '0'},
    'RWS': {'MASK': '1', 'RW1C': '0'},
}

def parse_register_definition(input_text):
    """
    解析寄存器定义文本，返回位类型列表和最高位号。
    """
    bit_types = {}
    highest_bit = -1

    # 使用正则表达式匹配位定义
    # 模式1: 单个位，如 "0 - Immediate Readiness (RO)"
    # 模式2: 位范围，如 "10:9 - DEVSEL# Timing (RO)"
    pattern_single = re.compile(r'^(\d+)\s*-\s*.*\((\w+)\)', re.IGNORECASE)
    pattern_range = re.compile(r'^(\d+):(\d+)\s*-\s*.*\((\w+)\)', re.IGNORECASE)

    # 逐行解析文本
    for line_num, line in enumerate(input_text.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue  # 跳过空行

        # 尝试匹配位范围
        match_range = pattern_range.match(line)
        if match_range:
            high_bit = int(match_range.group(1))
            low_bit = int(match_range.group(2))
            field_type = match_range.group(3).upper()

            if high_bit < low_bit:
                log_history("警告: 位范围无效。", "warning")
                continue

            for bit in range(low_bit, high_bit + 1):
                bit_types[bit] = field_type
                if bit > highest_bit:
                    highest_bit = bit
            continue  # 处理完毕，继续下一行

        # 尝试匹配单个位
        match_single = pattern_single.match(line)
        if match_single:
            bit = int(match_single.group(1))
            field_type = match_single.group(2).upper()
            bit_types[bit] = field_type
            if bit > highest_bit:
                highest_bit = bit
            continue  # 处理完毕，继续下一行

        # 如果行不匹配任何模式，视为未定义
        log_history(f"警告: 在第{line_num}行，未识别的格式。", "warning")
        continue

    return bit_types, highest_bit

def determine_register_width(highest_bit):
    """
    根据最高位号确定寄存器位宽。
    """
    for width in SUPPORTED_WIDTHS:
        if highest_bit < width:
            return width
    return None  # 超出支持的位宽

def generate_masks(bit_types, register_width):
    """
    根据位类型生成WRITEMASK和RW1C掩码。
    """
    writemask = ['0'] * register_width
    rw1c = ['0'] * register_width

    for bit in range(register_width):
        field_type = bit_types.get(bit, 'UNDEFINED')
        mapping = FIELD_TYPE_MAPPINGS.get(field_type, FIELD_TYPE_MAPPINGS['UNDEFINED'])
        writemask[bit] = mapping['MASK']
        rw1c[bit] = mapping['RW1C']

    # 将列表转换为字符串，从最高位到最低位
    writemask_str = ''.join(writemask[::-1])
    rw1c_str = ''.join(rw1c[::-1])

    # 生成BIT字符串（可以根据需求调整）
    bit_str = ''.join(writemask[::-1])  # 示例中与WRITEMASK相同

    return writemask_str, rw1c_str, bit_str

def bitstring_to_hex(bitstring):
    """
    将位字符串转换为16进制字符串。
    """
    try:
        # 确保位字符串长度是8的倍数
        length = len(bitstring)
        if length % 8 != 0:
            bitstring = bitstring.zfill(((length + 7) // 8) * 8)  # 左侧补0
        byte_count = len(bitstring) // 8
        bytes_list = [bitstring[i*8:(i+1)*8] for i in range(byte_count)]
        hex_str = ''.join([f"{int(byte, 2):02x}" for byte in bytes_list])
        return hex_str
    except Exception as e:
        log_history(f"错误在bitstring_to_hex: {e}", "warning")
        return "转换失败"

def endian_swap(hex_str):
    """
    交换16进制字符串的字节顺序（小端与大端转换）。
    """
    try:
        # 确保hex_str长度为偶数
        if len(hex_str) % 2 != 0:
            hex_str = '0' + hex_str
        bytes_list = [hex_str[i:i+2] for i in range(0, len(hex_str), 2)]
        swapped = ''.join(bytes_list[::-1])
        return swapped
    except Exception as e:
        log_history(f"错误在endian_swap: {e}", "warning")
        return "转换失败"

def on_convert_masks():
    log_button_click("识别文本")
    input_text = input_text_box.get("1.0", tk.END).strip()
    if not input_text:
        log_history("输入为空，请输入寄存器字段定义文本。", "warning")
        return

    bit_types, highest_bit = parse_register_definition(input_text)

    if highest_bit == -1:
        log_history("无效输入，未检测到任何位定义。请检查输入格式。", "warning")
        return

    register_width = determine_register_width(highest_bit)
    if not register_width:
        log_history(f"位宽过大，最高位号为 {highest_bit}，超过了支持的最大位宽32位。", "warning")
        return

    writemask_str, rw1c_str, bit_str = generate_masks(bit_types, register_width)

    # 构建位类型字符串
    bit_types_str = f"寄存器位宽: {register_width} 位\n位类型（从 bit0 到 bit{register_width -1}）：\n"
    for bit in range(register_width -1, -1, -1):
        field_type = bit_types.get(bit, 'UNDEFINED')
        bit_types_str += f"bit{bit}: {field_type}\n"

    # 构建输出文本
    output_text = f"{bit_types_str}\n---\n"
    output_text += f"WRITEMASK 的二进制表示为：\n{writemask_str} (bit{register_width-1}到bit0)\n"
    output_text += f"RW1C 的二进制表示为：\n{rw1c_str} (bit{register_width-1}到bit0)\n"
    output_text += f"BIT 的二进制表示为：\n{bit_str} (bit{register_width-1}到bit0)\n"

    # 设置输出文本
    output_box.configure(state='normal')
    output_box.delete("1.0", tk.END)
    output_box.insert(tk.END, output_text)
    output_box.configure(state='disabled')

    # 更新识别结果输出框
    mask_output.configure(state='normal')
    mask_output.delete("1.0", tk.END)
    mask_output.insert(tk.END, writemask_str)
    mask_output.configure(state='disabled')

    rw1c_output.configure(state='normal')
    rw1c_output.delete("1.0", tk.END)
    rw1c_output.insert(tk.END, rw1c_str)
    rw1c_output.configure(state='disabled')

    bit_output.configure(state='normal')
    bit_output.delete("1.0", tk.END)
    bit_output.insert(tk.END, bit_str)
    bit_output.configure(state='disabled')

    # 记录历史
    record_history(register_width, bit_types_str, writemask_str, rw1c_str, bit_str)

def on_convert_bitstring():
    log_button_click("转换位字符串")
    bitstring = bitstring_input.get().strip()
    if not bitstring:
        log_history("输入为空，请输入位字符串。", "warning")
        return

    bit_length = len(bitstring)
    if bit_length not in SUPPORTED_WIDTHS:
        log_history(f"不支持的位宽，当前只支持8位、16位和32位。您输入的位数为 {bit_length} 位。", "warning")
        return

    # 验证位字符串仅包含0和1
    if not re.fullmatch(r'[01]+', bitstring):
        log_history("无效的位字符串，位字符串应仅包含 '0' 和 '1'。", "warning")
        return

    # 转换为16进制
    hex_str = bitstring_to_hex(bitstring)
    if hex_str == "转换失败":
        log_history("位字符串转换为16进制失败。请检查输入格式。", "warning")
        return

    # 端序转换
    endian_hex = endian_swap(hex_str).lower()
    if endian_hex == "转换失败":
        log_history("端序转换失败。请检查输入格式。", "warning")
        return

    # 构建输出文本
    conversion_output = f"当前位数: {bit_length} 位\n"
    conversion_output += f"原始位字符串: {bitstring}\n"
    conversion_output += f"转换为16进制: {hex_str}\n"

    # 设置转换结果
    conversion_result = conversion_output + f"端序转换后的16进制: {endian_hex}\n"

    # 设置转换结果文本框
    bitstring_output_box.configure(state='normal')
    bitstring_output_box.delete("1.0", tk.END)
    bitstring_output_box.insert(tk.END, conversion_output)
    bitstring_output_box.configure(state='disabled')

    # 设置 COE 结果
    coe_output.configure(state='normal')
    coe_output.delete("1.0", tk.END)
    coe_output.insert(tk.END, endian_hex)
    coe_output.configure(state='disabled')

    # 记录历史
    record_history_bitstring(bit_length, bitstring, hex_str, endian_hex)

def clear_input_text():
    """
    清空寄存器字段定义输入框。
    """
    input_text_box.configure(state='normal')
    input_text_box.delete("1.0", tk.END)
    input_text_box.configure(state='disabled')
    log_history("输入文本框已清空。", "info")

def copy_mask_to_bitstring():
    log_button_click("复制 MASK 到位字符串")
    mask = mask_output.get("1.0", tk.END).strip()
    if not mask:
        log_history("无 MASK 数据，没有可复制的 MASK 数据。请先进行掩码转换。", "warning")
        return
    # 将MASK转换为16进制位字符串
    hex_str = bitstring_to_hex(mask)
    bit_length = len(mask)
    # 如果位数不是8的倍数，补齐
    if bit_length % 8 != 0:
        bit_length = ((bit_length + 7) // 8) * 8
        mask = mask.zfill(bit_length)
        hex_str = bitstring_to_hex(mask)
    # 更新位字符串输入框
    bitstring_input.delete(0, tk.END)
    bitstring_input.insert(0, mask)
    log_history("MASK 已复制到位字符串输入框。", "info")

def copy_rw1c_to_bitstring():
    log_button_click("复制 RW1C 到位字符串")
    rw1c = rw1c_output.get("1.0", tk.END).strip()
    if not rw1c:
        log_history("无 RW1C 数据，没有可复制的 RW1C 数据。请先进行掩码转换。", "warning")
        return
    # 将RW1C转换为16进制位字符串
    hex_str = bitstring_to_hex(rw1c)
    bit_length = len(rw1c)
    # 如果位数不是8的倍数，补齐
    if bit_length % 8 != 0:
        bit_length = ((bit_length + 7) // 8) * 8
        rw1c = rw1c.zfill(bit_length)
        hex_str = bitstring_to_hex(rw1c)
    # 更新位字符串输入框
    bitstring_input.delete(0, tk.END)
    bitstring_input.insert(0, rw1c)
    log_history("RW1C 已复制到位字符串输入框。", "info")

def record_history(register_width, bit_types_str, writemask_str, rw1c_str, bit_str):
    """
    记录寄存器掩码转换历史。
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    history_text = f"时间戳: {timestamp}\n"
    history_text += f"{bit_types_str}\n"
    history_text += f"WRITEMASK: {writemask_str}\n"
    history_text += f"RW1C: {rw1c_str}\n"
    history_text += f"BIT: {bit_str}\n"
    history_text += "-" * 50 + "\n"
    history_box.configure(state='normal')
    history_box.insert(tk.END, history_text, "info")
    history_box.configure(state='disabled')
    history_box.see(tk.END)  # 自动滚动到最新记录

def record_history_bitstring(bit_length, bitstring, hex_str, endian_hex):
    """
    记录位字符串转换历史。
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    history_text = f"时间戳: {timestamp}\n"
    history_text += f"位数: {bit_length} 位\n"
    history_text += f"原始位字符串: {bitstring}\n"
    history_text += f"转换为16进制: {hex_str}\n"
    history_text += f"端序转换后的16进制 (COE): {endian_hex}\n"
    history_text += "-" * 50 + "\n"
    history_box.configure(state='normal')
    history_box.insert(tk.END, history_text, "info")
    history_box.configure(state='disabled')
    history_box.see(tk.END)  # 自动滚动到最新记录

def log_history(message, msg_type="info"):
    """
    将不同类型的消息记录到历史记录框中。
    msg_type:
        - "warning" : 警告类信息，红色
        - "operation": 点击和操作日志，绿色
        - "info"     : 普通信息，黑色
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if msg_type == "warning":
        full_message = f"时间戳: {timestamp}\n{message}\n" + "-" * 50 + "\n"
        tag = "warning"
    elif msg_type == "operation":
        full_message = f"时间戳: {timestamp}\n{message}\n" + "-" * 50 + "\n"
        tag = "operation"
    else:  # "info"
        full_message = f"时间戳: {timestamp}\n{message}\n" + "-" * 50 + "\n"
        tag = "info"

    history_box.configure(state='normal')
    history_box.insert(tk.END, full_message, tag)
    history_box.configure(state='disabled')
    history_box.see(tk.END)  # 自动滚动到最新记录

def log_button_click(button_name):
    """
    记录按钮点击事件到历史记录框中，绿色字体显示。
    """
    message = f"按钮点击: {button_name}"
    log_history(message, "operation")

def replace_with_clipboard(event):
    """
    将剪贴板内容替换到寄存器字段定义输入框的全文。
    """
    try:
        clipboard_content = root.clipboard_get()
        input_text_box.configure(state='normal')
        input_text_box.delete("1.0", tk.END)
        input_text_box.insert(tk.END, clipboard_content)
        input_text_box.configure(state='disabled')
        log_history("输入文本框内容已替换为剪贴板内容。", "info")
    except tk.TclError:
        pass  # 没有剪贴板内容

def add_context_menu(text_widget):
    """
    为给定的文本部件添加右键复制菜单。
    """
    def show_context_menu(event):
        try:
            # 检查是否有选中的文本
            selected_text = text_widget.selection_get()
            context_menu.tk_popup(event.x_root, event.y_root)
        except tk.TclError:
            # 没有选中的文本，不显示菜单
            return

    def copy_selection():
        try:
            selected_text = text_widget.selection_get()
            root.clipboard_clear()
            root.clipboard_append(selected_text)
            log_history("选中的文本已复制到剪贴板。", "info")
        except tk.TclError:
            pass  # 没有选中的文本

    # 创建右键菜单
    context_menu = tk.Menu(root, tearoff=0)
    context_menu.add_command(label="复制", command=copy_selection)

    # 绑定右键点击事件
    text_widget.bind("<Button-3>", show_context_menu)













# 创建主窗口
root = tk.Tk()
root.title("Arbor decode工具 By:梦入神机dtt:### Rev1.0 #未经授权禁止外泄")
root.geometry("1400x900")  # 调整窗口大小以适应新增内容
root.minsize(1200, 800)  # 设置最小窗口大小

# 创建一个框架用于组织布局
main_paned = ttk.PanedWindow(root, orient=tk.HORIZONTAL)
main_paned.pack(fill=tk.BOTH, expand=True)

# 左侧主功能区
left_frame = ttk.Frame(main_paned, padding="10")
main_paned.add(left_frame, weight=3)

# 右侧历史记录区
right_frame = ttk.Frame(main_paned, padding="10")
main_paned.add(right_frame, weight=1)

# ======= 左侧功能区 =======

# ======= Mask Conversion Section =======

# 输入文本标签
input_label = ttk.Label(left_frame, text="decode字段定义文本输入:")
input_label.grid(row=0, column=0, sticky=tk.W)

# 输入文本框（可滚动）并设置等宽字体
input_text_box = scrolledtext.ScrolledText(left_frame, wrap=tk.WORD, font=("Courier", 10))
input_text_box.grid(row=1, column=0, columnspan=3, sticky="nsew", pady=5)

# 转换按钮
convert_masks_button = ttk.Button(left_frame, text="识别文本", command=on_convert_masks)
convert_masks_button.grid(row=2, column=0, pady=10, sticky=tk.W)

# 新增清空输入框按钮
clear_input_button = ttk.Button(left_frame, text="清空输入框", command=clear_input_text)
clear_input_button.grid(row=2, column=1, pady=10, padx=5, sticky=tk.W)  # 放置在转换按钮的右边

# 识别结果输出框框架
results_frame = ttk.LabelFrame(left_frame, text="识别结果")
results_frame.grid(row=3, column=0, columnspan=3, sticky="nsew", pady=5)

# 配置grid权重
left_frame.grid_rowconfigure(1, weight=1)  # 输入文本框行
left_frame.grid_rowconfigure(3, weight=1)  # 识别结果框架行
left_frame.grid_columnconfigure(0, weight=1)  # 主列
results_frame.grid_columnconfigure(1, weight=1)  # 输出框列

# WRITEMASK 输出框
mask_label = ttk.Label(results_frame, text="WRITEMASK:")
mask_label.grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
mask_output = scrolledtext.ScrolledText(results_frame, wrap=tk.WORD, height=2, state='disabled', font=("Courier", 10))
mask_output.grid(row=0, column=1, sticky="nsew", padx=5, pady=2)

# RW1C 输出框
rw1c_label = ttk.Label(results_frame, text="RW1C:")
rw1c_label.grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
rw1c_output = scrolledtext.ScrolledText(results_frame, wrap=tk.WORD, height=2, state='disabled', font=("Courier", 10))
rw1c_output.grid(row=1, column=1, sticky="nsew", padx=5, pady=2)

# BIT 输出框
bit_label = ttk.Label(results_frame, text="BIT:")
bit_label.grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
bit_output = scrolledtext.ScrolledText(results_frame, wrap=tk.WORD, height=2, state='disabled', font=("Courier", 10))
bit_output.grid(row=2, column=1, sticky="nsew", padx=5, pady=2)

# 复制按钮框架
copy_buttons_frame = ttk.Frame(left_frame)
copy_buttons_frame.grid(row=4, column=0, columnspan=3, sticky="ew", pady=5)

# 配置grid权重
copy_buttons_frame.grid_columnconfigure(0, weight=1)
copy_buttons_frame.grid_columnconfigure(1, weight=1)

# 复制 MASK 按钮
copy_mask_button = ttk.Button(copy_buttons_frame, text="复制 MASK 到位字符串", command=copy_mask_to_bitstring)
copy_mask_button.grid(row=0, column=0, padx=5, pady=2, sticky="ew")

# 复制 RW1C 按钮
copy_rw1c_button = ttk.Button(copy_buttons_frame, text="复制 RW1C 到位字符串", command=copy_rw1c_to_bitstring)
copy_rw1c_button.grid(row=0, column=1, padx=5, pady=2, sticky="ew")

# 输出文本标签
output_label = ttk.Label(left_frame, text="生成的掩码输出:")
output_label.grid(row=5, column=0, sticky=tk.W)

# 输出文本框（只读，可滚动）并设置等宽字体
output_box = scrolledtext.ScrolledText(left_frame, wrap=tk.WORD, state='disabled', font=("Courier", 10))
output_box.grid(row=6, column=0, columnspan=3, sticky="nsew", pady=5)

# ======= Bitstring Conversion Section =======

# 分隔符
separator = ttk.Separator(left_frame, orient='horizontal')
separator.grid(row=7, column=0, columnspan=3, sticky="ew", pady=20)

conversion_label = ttk.Label(left_frame, text="#####################COE转换###########################:")
conversion_label.grid(row=8, column=0, sticky=tk.W)

# 输入位字符串标签
bitstring_input_label = ttk.Label(left_frame, text="输入位字符串:")
bitstring_input_label.grid(row=9, column=0, sticky=tk.W, pady=(10, 0))

# 输入位字符串文本框
bitstring_input = ttk.Entry(left_frame)
bitstring_input.grid(row=10, column=0, columnspan=3, sticky="ew", pady=5)

# 转换按钮
convert_bitstring_button = ttk.Button(left_frame, text="转换位字符串", command=on_convert_bitstring)
convert_bitstring_button.grid(row=11, column=0, pady=10, sticky=tk.W)

# 输出位字符串转换结果标签
bitstring_output_label = ttk.Label(left_frame, text="转换结果:")
bitstring_output_label.grid(row=12, column=0, sticky=tk.W)

# 输出位字符串转换结果文本框（只读，可滚动）并设置等宽字体
bitstring_output_box = scrolledtext.ScrolledText(left_frame, wrap=tk.WORD, state='disabled', font=("Courier", 10))
bitstring_output_box.grid(row=13, column=0, columnspan=3, sticky="nsew", pady=5)

# 新增 COE 输出框
coe_label = ttk.Label(left_frame, text="COE:")
coe_label.grid(row=14, column=0, sticky=tk.W, pady=(10, 0))

coe_output = scrolledtext.ScrolledText(left_frame, wrap=tk.WORD, height=2, state='disabled', font=("Courier", 10))
coe_output.grid(row=15, column=0, columnspan=3, sticky="ew", pady=5)

# 配置grid权重
left_frame.grid_rowconfigure(1, weight=1)    # 输入文本框行
left_frame.grid_rowconfigure(3, weight=0)    # 识别结果框架行
left_frame.grid_rowconfigure(6, weight=1)    # 输出掩码框行
left_frame.grid_rowconfigure(13, weight=1)   # 位字符串转换结果行
left_frame.grid_columnconfigure(0, weight=1)  # 主列

# ======= 右侧历史记录区 =======

history_label = ttk.Label(right_frame, text="历史记录:")
history_label.pack(anchor=tk.W)

# 历史记录文本框（只读，可滚动）并设置等宽字体
history_box = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD, state='disabled', font=("Courier", 10))
history_box.pack(fill=tk.BOTH, expand=True, pady=5)

# 定义文本标签的颜色
history_box.tag_configure("warning", foreground="red")
history_box.tag_configure("operation", foreground="green")
history_box.tag_configure("info", foreground="black")

# 为 history_box 添加复制右键功能
add_context_menu(history_box)

# 为其他文本框添加复制右键功能
# 移除对 input_text_box 的右键菜单绑定
# add_context_menu(input_text_box)  # 这行被移除

# 添加右键替换功能到 input_text_box
input_text_box.bind("<Button-3>", replace_with_clipboard)

# 为其他文本框添加复制右键功能
add_context_menu(mask_output)
add_context_menu(rw1c_output)
add_context_menu(bit_output)
add_context_menu(output_box)
add_context_menu(bitstring_output_box)
add_context_menu(coe_output)

# 运行主循环
root.mainloop()
