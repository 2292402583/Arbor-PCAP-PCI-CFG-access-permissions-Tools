@echo off
python "%~dp0\66.py"
pause
